package com.trsub.app

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/** إعدادات التطبيق المحفوظة على الهاتف. */
class Settings(ctx: Context) {
    private val p: SharedPreferences = open(ctx)

    /** تخزين مشفّر (مفتاح API لا يُحفظ كنص عادي). مع ترحيل تلقائي من التخزين القديم. */
    private fun open(ctx: Context): SharedPreferences {
        val plain = ctx.getSharedPreferences("trsub", Context.MODE_PRIVATE)
        return try {
            val mk = MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
            val enc = EncryptedSharedPreferences.create(
                ctx, "trsub_secure", mk,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
            val old = plain.all
            if (old.isNotEmpty()) {
                val e = enc.edit()
                for ((k, v) in old) {
                    when (v) {
                        is String -> e.putString(k, v)
                        is Boolean -> e.putBoolean(k, v)
                        is Float -> e.putFloat(k, v)
                        is Int -> e.putInt(k, v)
                        is Long -> e.putLong(k, v)
                    }
                }
                e.apply()
                plain.edit().clear().apply()
            }
            enc
        } catch (e: Exception) {
            plain // احتياط إذا فشل Keystore على بعض الأجهزة
        }
    }

    var key: String
        get() = p.getString("key", "") ?: ""
        set(v) { p.edit().putString("key", v).apply() }

    var url: String
        get() = p.getString("url", DEFAULT_URL) ?: DEFAULT_URL
        set(v) { p.edit().putString("url", v).apply() }

    var whisperModel: String
        get() = p.getString("whisper", DEFAULT_WHISPER) ?: DEFAULT_WHISPER
        set(v) { p.edit().putString("whisper", v).apply() }

    var llmModel: String
        get() {
            val saved = p.getString("llm", null)
            // ترحيل تلقائي من النموذج القديم المتوقف على حسابات Groq العادية.
            if (saved == null || saved == "llama-3.3-70b-versatile") {
                p.edit().putString("llm", DEFAULT_LLM).apply()
                return DEFAULT_LLM
            }
            return saved
        }
        set(v) { p.edit().putString("llm", v).apply() }

    var smart: Boolean
        get() = p.getBoolean("smart", true)
        set(v) { p.edit().putBoolean("smart", v).apply() }

    var autoPause: Boolean
        get() = p.getBoolean("autoPause", true)
        set(v) { p.edit().putBoolean("autoPause", v).apply() }

    var bg: Boolean
        get() = p.getBoolean("bg", true)
        set(v) { p.edit().putBoolean("bg", v).apply() }

    var fontSize: Float
        get() = p.getFloat("font", 20f)
        set(v) { p.edit().putFloat("font", v).apply() }

    var fontStyle: String
        get() = p.getString("fontStyle", "normal") ?: "normal"
        set(v) { p.edit().putString("fontStyle", v).apply() }

    /** إزاحة التوقيت بالثواني: موجب = تظهر الترجمة أبكر. */
    var shift: Float
        get() = p.getFloat("shift", 0f)
        set(v) { p.edit().putFloat("shift", v).apply() }

    var lang: String
        get() = p.getString("lang", "auto") ?: "auto"
        set(v) { p.edit().putString("lang", v).apply() }

    /** لغة الترجمة النهائية: ar أو en. */
    var targetLang: String
        get() = p.getString("targetLang", "ar") ?: "ar"
        set(v) { p.edit().putString("targetLang", if (v == "en") "en" else "ar").apply() }

    companion object {
        const val DEFAULT_URL = "https://api.groq.com/openai/v1"
        const val DEFAULT_WHISPER = "whisper-large-v3-turbo"
        const val DEFAULT_LLM = "openai/gpt-oss-120b"
    }
}
