package com.trsub.app

import android.content.Context
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.os.Build
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder

class ChunkAudio(val file: File, val baseSec: Double, val mime: String)

/**
 * يقتطع جزءاً من المسار الصوتي للفيديو إلى ملف صغير.
 * - AAC (وOpus/Vorbis على أندرويد 10+): نسخ مباشر بدون إعادة ترميز.
 * - أي صيغة أخرى (AC3 / EAC3 / DTS / MP3 / FLAC ...): فك الترميز إلى WAV أحادي 16kHz.
 */
object AudioChunker {

    private const val WAV_RATE = 16_000
    private const val DECODE_TIMEOUT_MS = 60_000L

    /**
     * يرجع الملف + زمن أول عينة فيه (بالثواني، على خط زمن الفيديو)،
     * أو null إذا لم يوجد صوت في هذا الجزء.
     */
    fun extract(ctx: Context, uri: Uri, startUs: Long, endUs: Long, dir: File, name: String): ChunkAudio? {
        val ex = MediaExtractor()
        try {
            ex.setDataSource(ctx, uri, null)
            var track = -1
            for (i in 0 until ex.trackCount) {
                val m = ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: continue
                if (m.startsWith("audio/")) { track = i; break }
            }
            if (track < 0) throw IllegalStateException("لا يوجد مسار صوتي في الفيديو")
            val fmt = ex.getTrackFormat(track)
            val mime = fmt.getString(MediaFormat.KEY_MIME) ?: ""
            ex.selectTrack(track)
            ex.seekTo(startUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)

            val ogg = (mime == "audio/opus" || mime == "audio/vorbis") && Build.VERSION.SDK_INT >= 29
            val direct = mime == MediaFormat.MIMETYPE_AUDIO_AAC || ogg
            if (direct) {
                try {
                    return passthrough(ex, fmt, ogg, endUs, dir, name)
                } catch (e: Exception) {
                    // الـ muxer رفض الصيغة: نرجع للتحويل إلى WAV
                    ex.seekTo(startUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
                }
            }
            return decodeToWav(ex, fmt, mime, endUs, dir, name)
        } finally {
            ex.release()
        }
    }

    // ---------------------------------------------------------------- نسخ مباشر

    private fun passthrough(
        ex: MediaExtractor, fmt: MediaFormat, ogg: Boolean, endUs: Long, dir: File, name: String
    ): ChunkAudio? {
        var muxer: MediaMuxer? = null
        var started = false
        var out: File? = null
        var result: ChunkAudio? = null
        try {
            val f = File(dir, name + if (ogg) ".ogg" else ".m4a")
            out = f
            val mx = MediaMuxer(
                f.absolutePath,
                if (ogg) MediaMuxer.OutputFormat.MUXER_OUTPUT_OGG else MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4
            )
            muxer = mx
            val dst = mx.addTrack(fmt)
            mx.start()
            started = true

            val buf = ByteBuffer.allocate(1 shl 20)
            val info = MediaCodec.BufferInfo()
            var base = -1L
            var written = 0
            while (true) {
                buf.clear()
                val size = ex.readSampleData(buf, 0)
                if (size < 0) break
                val t = ex.sampleTime
                if (t >= endUs) break
                if (base < 0) base = t
                info.set(0, size, t - base, ex.sampleFlags)
                mx.writeSampleData(dst, buf, info)
                written++
                ex.advance()
            }
            if (written > 0) {
                result = ChunkAudio(f, base / 1_000_000.0, if (ogg) "audio/ogg" else "audio/mp4")
            }
        } catch (e: Exception) {
            out?.delete()
            throw e
        } finally {
            try { if (started) muxer?.stop() } catch (_: Exception) {}
            try { muxer?.release() } catch (_: Exception) {}
        }
        if (result == null) out?.delete()
        return result
    }

    // ---------------------------------------------------------------- فك الترميز إلى WAV

    private class MonoBuf {
        var a = ShortArray(1 shl 16)
        var n = 0
        fun add(v: Short) {
            if (n == a.size) a = a.copyOf(a.size * 2)
            a[n++] = v
        }
    }

    private fun unsupported(mime: String) = IllegalStateException("صيغة الصوت غير مدعومة على هذا الهاتف ($mime)")

    private fun decodeToWav(
        ex: MediaExtractor, fmt: MediaFormat, mime: String, endUs: Long, dir: File, name: String
    ): ChunkAudio? {
        val codec = try {
            MediaCodec.createDecoderByType(mime)
        } catch (e: Exception) {
            throw unsupported(mime)
        }
        try {
            try {
                codec.configure(fmt, null, null, 0)
                codec.start()
            } catch (e: Exception) {
                throw unsupported(mime)
            }

            var rate = if (fmt.containsKey(MediaFormat.KEY_SAMPLE_RATE)) fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE) else 48_000
            var ch = if (fmt.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else 2
            var floatPcm = false

            val mono = MonoBuf()
            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false
            var baseUs = -1L
            val deadline = System.currentTimeMillis() + DECODE_TIMEOUT_MS

            while (!outputDone) {
                if (System.currentTimeMillis() > deadline) throw IllegalStateException("انتهت مهلة فك ترميز الصوت")

                if (!inputDone) {
                    val inIdx = codec.dequeueInputBuffer(10_000)
                    if (inIdx >= 0) {
                        val ib = codec.getInputBuffer(inIdx)!!
                        ib.clear()
                        val size = ex.readSampleData(ib, 0)
                        val t = ex.sampleTime
                        if (size < 0 || t >= endUs) {
                            codec.queueInputBuffer(inIdx, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            codec.queueInputBuffer(inIdx, 0, size, t, 0)
                            ex.advance()
                        }
                    }
                }

                val outIdx = codec.dequeueOutputBuffer(info, 10_000)
                if (outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val of = codec.outputFormat
                    if (of.containsKey(MediaFormat.KEY_SAMPLE_RATE)) rate = of.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    if (of.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) ch = of.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    floatPcm = of.containsKey(MediaFormat.KEY_PCM_ENCODING) &&
                        of.getInteger(MediaFormat.KEY_PCM_ENCODING) == AudioFormat.ENCODING_PCM_FLOAT
                } else if (outIdx >= 0) {
                    if (info.size > 0) {
                        val ob = codec.getOutputBuffer(outIdx)!!
                        ob.position(info.offset)
                        ob.limit(info.offset + info.size)
                        if (baseUs < 0) baseUs = info.presentationTimeUs
                        appendMono(ob, ch.coerceAtLeast(1), floatPcm, mono)
                    }
                    codec.releaseOutputBuffer(outIdx, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outputDone = true
                }
            }

            if (mono.n == 0 || baseUs < 0) return null
            val pcm = toRate16k(mono.a, mono.n, rate.coerceAtLeast(1))
            if (pcm.isEmpty()) return null
            val f = File(dir, "$name.wav")
            writeWav(f, pcm, WAV_RATE)
            return ChunkAudio(f, baseUs / 1_000_000.0, "audio/wav")
        } finally {
            try { codec.stop() } catch (_: Exception) {}
            try { codec.release() } catch (_: Exception) {}
        }
    }

    /** يحوّل إطارات PCM (متعددة القنوات) إلى قناة واحدة. */
    private fun appendMono(ob: ByteBuffer, ch: Int, floatPcm: Boolean, out: MonoBuf) {
        ob.order(ByteOrder.nativeOrder())
        if (floatPcm) {
            val fb = ob.asFloatBuffer()
            val frames = fb.remaining() / ch
            for (i in 0 until frames) {
                var sum = 0f
                for (c in 0 until ch) sum += fb.get()
                val v = (sum / ch * 32767f).toInt().coerceIn(-32768, 32767)
                out.add(v.toShort())
            }
        } else {
            val sb = ob.asShortBuffer()
            val frames = sb.remaining() / ch
            for (i in 0 until frames) {
                var sum = 0
                for (c in 0 until ch) sum += sb.get().toInt()
                out.add((sum / ch).toShort())
            }
        }
    }

    /** تقليل معدل العينات إلى 16kHz بمتوسط النوافذ (يخفف التشويه). */
    private fun toRate16k(src: ShortArray, n: Int, srcRate: Int): ShortArray {
        if (srcRate == WAV_RATE) return src.copyOf(n)
        val ratio = srcRate.toDouble() / WAV_RATE
        val outLen = (n / ratio).toInt()
        val out = ShortArray(outLen)
        for (i in 0 until outLen) {
            val a = (i * ratio).toInt().coerceAtMost(n - 1)
            val b = ((i + 1) * ratio).toInt().coerceAtLeast(a + 1).coerceAtMost(n)
            var sum = 0L
            for (k in a until b) sum += src[k]
            out[i] = (sum / (b - a)).toShort()
        }
        return out
    }

    private fun writeWav(f: File, pcm: ShortArray, rate: Int) {
        val dataLen = pcm.size * 2
        val bb = ByteBuffer.allocate(44 + dataLen).order(ByteOrder.LITTLE_ENDIAN)
        bb.put("RIFF".toByteArray()); bb.putInt(36 + dataLen)
        bb.put("WAVE".toByteArray()); bb.put("fmt ".toByteArray()); bb.putInt(16)
        bb.putShort(1); bb.putShort(1)            // PCM, mono
        bb.putInt(rate); bb.putInt(rate * 2)
        bb.putShort(2); bb.putShort(16)
        bb.put("data".toByteArray()); bb.putInt(dataLen)
        for (s in pcm) bb.putShort(s)
        f.writeBytes(bb.array())
    }
}
