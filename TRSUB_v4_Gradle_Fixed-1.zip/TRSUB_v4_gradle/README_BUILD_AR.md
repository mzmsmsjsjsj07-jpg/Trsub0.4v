TR.SUB v4 — بناء APK عبر GitHub Actions

1) ارفع محتويات هذا المجلد إلى المستودع على GitHub (لا ترفع ملف ZIP نفسه داخل المستودع).
2) افتح تبويب Actions.
3) اختر Build TR.SUB APK ثم Run workflow، أو ادفع Commit جديدًا.
4) بعد نجاح البناء افتح نتيجة التشغيل ونزّل Artifact باسم TR.SUB-APK.
5) فك ضغط Artifact لتحصل على TR.SUB.apk.

إعدادات البناء:
- Java 17
- Gradle 8.7
- Android SDK platform 34
- Android build-tools 34.0.0

ملاحظة: ملف المشروع لا يحتوي على Gradle Wrapper (gradlew)، لذلك يثبّت سير العمل Gradle 8.7 داخل بيئة GitHub Actions ويشغّل أمر gradle assembleDebug مباشرة.
